package com.employee.entity;

public enum Status {

	ACTIVE, INACTIVE;
}
